import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-page-found2',
  templateUrl: './no-page-found2.component.html',
  styleUrls: ['./no-page-found2.component.css']
})
export class NoPageFound2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
